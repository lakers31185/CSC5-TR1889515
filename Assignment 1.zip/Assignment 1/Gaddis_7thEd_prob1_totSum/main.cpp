/* 
 * File:   main.cpp
 * Author: Tony Reyes
 * June 25, 2014
 * Purpose: Sum of 2 Numbers
 */


//System Level Libraries
#include <iostream>
using namespace std;


//User Defined Libraries


//Global Constants


//Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv) {
        
        //Declare and initialize variables
        int short Y= 62; //Variable Number One
        int short X= 99; //Variable Number Two
        int short totVar; //Sum of X and Y
        
        //Calculate the Sum of Variable One & Two  
        totVar= X+Y;
        
        //Output the results
        cout<< "Variable Number One= " <<Y<<endl;
        cout<< "Variable Number Two= " <<X<<endl;
        cout<< "Sum of Variables= " <<totVar<<endl;
        
    return 0;
}
