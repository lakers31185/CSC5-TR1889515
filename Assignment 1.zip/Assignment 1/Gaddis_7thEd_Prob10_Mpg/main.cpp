/* 
 * File:   main.cpp
 * Author: Tony Reyes
 * June 25, 2014, 3:43 PM
 * Purpose: Gaddis 7thEd Prob10 Miles Per Gallon
 */

//System Library
#include <iostream>
#include <iomanip>
using namespace std;

//User Defined Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv){
    
    //Declare and initialize variables
    const int carGal= 12; //Amount Fuel Car Holds (gallons)
    float disTra= 350; //Distance Traveled Before Refueling (miles)
    float mPg; //Declared Variable
    
    //Calculations for Miles per Gallon
    mPg=disTra/carGal;
    
    //Output the Results
    cout<<setprecision(2)<<fixed;
    cout<<"Miles per Gallon for Car= " <<mPg<<endl;
    
     //Exit stage right!   
    return 0;
   
}

    
    